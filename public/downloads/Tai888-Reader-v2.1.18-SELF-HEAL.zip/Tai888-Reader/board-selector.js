import { canonicalReaderPayload } from './parser.js';

export const BOARD_ACTIVITY_TTL_MS = 5 * 60 * 1000;
// Kept for diagnostic compatibility only. Candidate selection is board-based,
// never blocked merely because the user opened a fifth Tai888 page.
export const MAX_TAI888_TABS = Number.POSITIVE_INFINITY;

export function withinTai888TabScanLimit(value) {
  return Number.isInteger(value) && value >= 0;
}

const LINE_TOKEN = /^(?:\d+(?:\.\d+)?(?:\/\d+(?:\.\d+)?)?)(?:平|[+-]\d{1,3})?$/;
const DATE_TOKEN = /^\d{4}-\d{2}-\d{2}$/;
const TIME_TOKEN = /^(?:[01]\d|2[0-3]):[0-5]\d$/;
const TEAM_CODE = /^[A-Z][A-Z0-9]{0,11}$/;
const LEAGUES = new Set(['MLB', 'NPB', 'KBO', 'CPBL']);

const finiteInteger = value => {
  const number = Number(value);
  return Number.isInteger(number) ? number : null;
};

export function validReaderWater(value) {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0.01 && value <= 3;
}

function validLine(value) {
  return LINE_TOKEN.test(String(value || '').trim());
}

function validateRunline(value, name, issues) {
  if (!value || typeof value !== 'object') {
    issues.push(`${name}:missing`);
    return 0;
  }
  if (value.lineSide !== 'away' && value.lineSide !== 'home') issues.push(`${name}:ambiguous-side`);
  if (!validLine(value.line)) issues.push(`${name}:invalid-line`);
  if (!validReaderWater(value.awayWater)) issues.push(`${name}:invalid-away-water`);
  if (!validReaderWater(value.homeWater)) issues.push(`${name}:invalid-home-water`);
  return 2;
}

function validateTotal(value, name, issues) {
  if (!value || typeof value !== 'object') {
    issues.push(`${name}:missing`);
    return 0;
  }
  if (!validLine(value.line)) issues.push(`${name}:invalid-line`);
  if (!validReaderWater(value.overWater)) issues.push(`${name}:invalid-over-water`);
  if (!validReaderWater(value.underWater)) issues.push(`${name}:invalid-under-water`);
  return 2;
}

export function validateStandardReaderGame(game) {
  const issues = [];
  if (!TEAM_CODE.test(String(game?.awayCode || ''))) issues.push('invalid-away-code');
  if (!TEAM_CODE.test(String(game?.homeCode || ''))) issues.push('invalid-home-code');
  if (game?.awayCode === game?.homeCode) issues.push('same-team');
  if (!DATE_TOKEN.test(String(game?.boardDate || ''))) issues.push('invalid-date');
  if (!TIME_TOKEN.test(String(game?.boardTime || ''))) issues.push('invalid-time');

  let directionCount = 0;
  directionCount += validateRunline(game?.fullRunline, 'full-runline', issues);
  directionCount += validateTotal(game?.fullTotal, 'full-total', issues);
  directionCount += validateRunline(game?.first5Runline, 'first5-runline', issues);
  directionCount += validateTotal(game?.first5Total, 'first5-total', issues);
  if (directionCount !== 8) issues.push(`direction-count:${directionCount}`);

  return { ok: issues.length === 0, issues, directionCount };
}

function validateLockedReaderGame(game) {
  const issues = [];
  if (!TEAM_CODE.test(String(game?.awayCode || ''))) issues.push('invalid-away-code');
  if (!TEAM_CODE.test(String(game?.homeCode || ''))) issues.push('invalid-home-code');
  if (game?.awayCode === game?.homeCode) issues.push('same-team');
  if (!DATE_TOKEN.test(String(game?.boardDate || ''))) issues.push('invalid-date');
  if (!TIME_TOKEN.test(String(game?.boardTime || ''))) issues.push('invalid-time');
  if (game?.marketStatus !== 'locked') issues.push('missing-explicit-lock');
  if ([game?.fullRunline, game?.fullTotal, game?.first5Runline, game?.first5Total].some(Boolean)) {
    issues.push('locked-game-has-market');
  }
  return { ok: issues.length === 0, issues, directionCount: 0 };
}

function validateAvailableReaderGame(game) {
  const identity = [];
  if (!TEAM_CODE.test(String(game?.awayCode || ''))) identity.push('invalid-away-code');
  if (!TEAM_CODE.test(String(game?.homeCode || ''))) identity.push('invalid-home-code');
  if (game?.awayCode === game?.homeCode) identity.push('same-team');
  if (!DATE_TOKEN.test(String(game?.boardDate || ''))) identity.push('invalid-date');
  if (!TIME_TOKEN.test(String(game?.boardTime || ''))) identity.push('invalid-time');
  const issues = [...identity];
  let directionCount = 0;
  const definitions = [
    ['full-runline', game?.fullRunline, validateRunline],
    ['full-total', game?.fullTotal, validateTotal],
    ['first5-runline', game?.first5Runline, validateRunline],
    ['first5-total', game?.first5Total, validateTotal],
  ];
  for (const [name, value, validate] of definitions) {
    if (value == null) continue;
    directionCount += validate(value, name, issues);
  }
  if (directionCount < 2) issues.push(`direction-count:${directionCount}`);
  return { ok: issues.length === 0, issues, directionCount };
}

export function assessBoardCandidate(candidate, now = Date.now()) {
  const capture = candidate?.capture || {};
  const parsed = candidate?.parsed || {};
  const diagnostics = capture?.diagnostics || {};
  const issues = [];
  const games = Array.isArray(parsed.games) ? parsed.games : [];
  const normalizedCandidate = candidate;
  const expectedGameCount = finiteInteger(diagnostics.expectedGameCount);
  const rawDetectedGameCount = finiteInteger(diagnostics.gameCount);
  // Tai888 renders duplicate responsive/measurement nodes for the same event.
  // `parsed.games` is already canonicalized by date/time/teams and rejects
  // conflicting duplicates, so it is the authoritative detected game count.
  const detectedGameCount = games.length;

  const sourceHost = String(capture.sourceHost || '').toLowerCase();
  if (sourceHost !== 'tai888.in' && !sourceHost.endsWith('.tai888.in')) issues.push('invalid-source-host');

  if (!Array.isArray(capture.tables) || capture.tables.length < 1) issues.push('no-board-table');
  if (!expectedGameCount || expectedGameCount < 1 || expectedGameCount > 30) {
    issues.push('missing-expected-game-count');
  }
  if (rawDetectedGameCount == null || rawDetectedGameCount < 1) issues.push('missing-detected-game-count');
  if (!games.length) issues.push('no-parsed-games');
  // Tai888 keeps locked events in the league header count, but some rendered
  // lock rows expose no usable DOM identity at all.  A smaller parsed set is
  // therefore allowed only as a fail-closed subset: every parsed event still
  // has to be a complete 4-market board (or an explicitly captured lock), and
  // the server will reconcile the absent identities against the official
  // slate as non-executable events.
  if (expectedGameCount && games.length > expectedGameCount) {
    issues.push(`expected-${expectedGameCount}-parsed-${games.length}`);
  }
  if (rawDetectedGameCount != null && rawDetectedGameCount < games.length) {
    issues.push(`raw-detected-${rawDetectedGameCount}-parsed-${games.length}`);
  }
  const ignoredDuplicateGameCount = Array.isArray(diagnostics.conflictingGameKeys)
    ? diagnostics.conflictingGameKeys.length
    : 0;
  if (Array.isArray(parsed.parseIssues) && parsed.parseIssues.length) {
    issues.push(...parsed.parseIssues
      .filter(issue => !String(issue).startsWith('conflicting-duplicate:'))
      .map(issue => `parser:${issue}`));
  }

  const identities = new Set();
  const dates = new Set();
  for (const [index, game] of games.entries()) {
    const validation = game?.marketStatus === 'locked'
      ? validateLockedReaderGame(game)
      : validateAvailableReaderGame(game);
    issues.push(...validation.issues.map(issue => `game-${index + 1}:${issue}`));
    const identity = `${game?.boardDate || ''}|${game?.boardTime || ''}|${game?.awayCode || ''}|${game?.homeCode || ''}`;
    if (identities.has(identity)) issues.push(`duplicate-game:${identity}`);
    identities.add(identity);
    if (game?.boardDate) dates.add(game.boardDate);
  }
  if (dates.size !== 1) issues.push(`board-date-count:${dates.size}`);
  if (dates.size === 1 && parsed.boardDate !== [...dates][0]) issues.push('board-date-mismatch');

  const observedTime = Date.parse(capture.observedAt || '');
  const observedAgeMs = Number(now) - observedTime;
  if (!Number.isFinite(observedTime)) issues.push('missing-observed-time');
  else if (observedAgeMs < -30_000 || observedAgeMs > 60_000) issues.push('stale-observation');

  // A successful content-script response proves only that the DOM is readable.
  // It must not renew the executable price time on a disconnected/frozen page.
  // Only an actual market fingerprint mutation can advance pageActivityAt.
  const marketActivityAt = String(diagnostics.lastMutationAt || '');
  const marketActivityTime = Date.parse(marketActivityAt);
  const marketActivityAgeMs = Number(now) - marketActivityTime;
  if (!Number.isFinite(marketActivityTime)) issues.push('missing-market-activity');
  else if (marketActivityAgeMs < -30_000) issues.push('future-market-activity');
  else if (marketActivityAgeMs > BOARD_ACTIVITY_TTL_MS) issues.push('stale-market-activity');
  const pageActivityAt = Number.isFinite(marketActivityTime) ? new Date(marketActivityTime).toISOString() : '';
  const pageActivityTime = marketActivityTime;

  return {
    ok: issues.length === 0,
    issues,
    candidate: normalizedCandidate,
    expectedGameCount,
    detectedGameCount,
    rawDetectedGameCount,
    ignoredDuplicateGameCount,
    pageActivityAt,
    pageActivityTime,
    marketActivityAt,
    marketActivityTime,
    // Host/frame metadata identifies the source but must not make two frames
    // with the exact same contracts appear to disagree.
    payloadFingerprint: games.length ? canonicalReaderPayload({ ...parsed, games, sourceHost: '' }) : '',
  };
}

function tabPriority(left, right, preferredTabId) {
  // A delayed mutation from a background/old tab must never outrank the tab
  // the user is currently viewing.  `preferredTabId` is only a tie-breaker
  // among tabs that Chrome still reports as active at capture time.
  const leftPreferred = left.active && left.tabId === preferredTabId ? 1 : 0;
  const rightPreferred = right.active && right.tabId === preferredTabId ? 1 : 0;
  if (leftPreferred !== rightPreferred) return rightPreferred - leftPreferred;
  if (Boolean(left.active) !== Boolean(right.active)) return Number(Boolean(right.active)) - Number(Boolean(left.active));
  const accessed = Number(right.lastAccessed || 0) - Number(left.lastAccessed || 0);
  if (accessed) return accessed;
  return Number(left.tabId || 0) - Number(right.tabId || 0);
}

function framePriority(left, right) {
  const leftBoardUrl = /\/newapp\/(?:#\/)?BS(?:\b|[/?#])/i.test(String(left.candidate?.capture?.pageUrl || '')) ? 1 : 0;
  const rightBoardUrl = /\/newapp\/(?:#\/)?BS(?:\b|[/?#])/i.test(String(right.candidate?.capture?.pageUrl || '')) ? 1 : 0;
  if (leftBoardUrl !== rightBoardUrl) return rightBoardUrl - leftBoardUrl;
  if (left.pageActivityTime !== right.pageActivityTime) return right.pageActivityTime - left.pageActivityTime;
  const leftObserved = Date.parse(left.candidate?.capture?.observedAt || '') || 0;
  const rightObserved = Date.parse(right.candidate?.capture?.observedAt || '') || 0;
  if (leftObserved !== rightObserved) return rightObserved - leftObserved;
  return Number(left.candidate?.frameId || 0) - Number(right.candidate?.frameId || 0);
}

/**
 * Pick one board from one frame in one authoritative tab.  The function never
 * combines tables or games across frames.  If two complete frames in that tab
 * disagree, it fails closed instead of guessing which contract is current.
 */
export function selectAuthoritativeBoard(candidates, { now = Date.now(), preferredTabId = null, league = '' } = {}) {
  if (league && !LEAGUES.has(league)) return { ok: false, error: 'unknown-league', assessed: [] };
  const boardCandidates = (Array.isArray(candidates) ? candidates : [])
    .filter(candidate => (!league || candidate?.parsed?.league === league)
      && Array.isArray(candidate?.capture?.tables) && candidate.capture.tables.length > 0);
  if (!boardCandidates.length) {
    return { ok: false, error: 'no-board-candidates', assessed: [] };
  }

  const tabs = [...new Map(boardCandidates.map(candidate => [candidate.tabId, {
    tabId: candidate.tabId,
    active: candidate.active,
    lastAccessed: candidate.lastAccessed,
  }])).values()].sort((left, right) => tabPriority(left, right, preferredTabId));
  const assessed = boardCandidates.map(candidate => assessBoardCandidate(candidate, now));
  const usableTabs = [];
  for (const tab of tabs) {
    const tabFrames = assessed.filter(row => row.candidate.tabId === tab.tabId);
    const validTabFrames = tabFrames.filter(row => row.ok);
    const bestCoverage = Math.max(0, ...validTabFrames.map(row => row.detectedGameCount || 0));
    const complete = validTabFrames.filter(row => row.detectedGameCount === bestCoverage);
    if (!complete.length) continue;
    usableTabs.push({
      tab,
      selected: [...complete].sort(framePriority)[0],
      duplicateFrameCount: Math.max(0, complete.length - 1),
    });
  }

  // Multiple tabs for the same league are safe only when they expose the exact
  // same canonical contracts. Never select a stale duplicate by focus/access
  // order when another usable tab shows a different price.
  const fingerprints = new Set(usableTabs.map(row => row.selected.payloadFingerprint).filter(Boolean));
  if (fingerprints.size > 1) {
    return {
      ok: false,
      error: 'conflicting-duplicate-tabs',
      authorityTabId: null,
      conflictingTabIds: usableTabs.map(row => row.tab.tabId),
      assessed,
    };
  }

  if (usableTabs.length) {
    const authority = [...usableTabs].sort((left, right) =>
      tabPriority(left.tab, right.tab, preferredTabId))[0];
    return {
      ok: true,
      authorityTabId: authority.tab.tabId,
      selected: authority.selected,
      ignoredDuplicateTabCount: Math.max(0, usableTabs.length - 1),
      ignoredDuplicateFrameCount: authority.duplicateFrameCount,
      assessed,
    };
  }

  return {
    ok: false,
    error: 'no-complete-tab',
    authorityTabId: tabs[0]?.tabId,
    assessed,
  };
}

export function shouldSkipSuccessfulPayload({
  reason,
  payloadHash,
  lastSuccessfulPayloadHash,
  lastSuccessfulSyncAt,
  now = Date.now(),
  minimumHeartbeatMs = 45_000,
} = {}) {
  const ageMs = Number(now) - Number(lastSuccessfulSyncAt || 0);
  return reason !== 'manual'
    && Boolean(payloadHash)
    && payloadHash === lastSuccessfulPayloadHash
    && ageMs >= 0
    && ageMs < minimumHeartbeatMs;
}
