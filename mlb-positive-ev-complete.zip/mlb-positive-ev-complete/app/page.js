'use client';

import { useEffect, useMemo, useState } from 'react';

const ORDER = ['全場讓分','全場大小','上半讓分','上半大小'];

function fmtPct(v){ return `${(Number(v||0)*100).toFixed(1)}%`; }
function fmtEV(v){ const n=Number(v||0)*100; return `${n>=0?'+':''}${n.toFixed(2)}%`; }
function normalizeName(s=''){ return s.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]/g,''); }
function teamMatch(parsed, game){
  const p = normalizeName(`${parsed.away}${parsed.home}`);
  const g1 = normalizeName(game.away), g2 = normalizeName(game.home);
  const tokens = [g1,g2].map(x=>x.slice(-6)).filter(Boolean);
  return tokens.reduce((a,t)=>a+(p.includes(t)?1:0),0);
}
async function fileToDataUrl(file){
  return new Promise((resolve,reject)=>{
    const r=new FileReader(); r.onload=()=>resolve(r.result); r.onerror=reject; r.readAsDataURL(file);
  });
}

export default function Home(){
  const [tab,setTab]=useState('today');
  const [date,setDate]=useState(()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Taipei'}).format(new Date()));
  const [games,setGames]=useState([]);
  const [loadingGames,setLoadingGames]=useState(false);
  const [images,setImages]=useState([]);
  const [visionStatus,setVisionStatus]=useState('');
  const [parsedGames,setParsedGames]=useState([]);
  const [selectedIndex,setSelectedIndex]=useState(0);
  const [locked,setLocked]=useState([]);
  const [analyses,setAnalyses]=useState({});
  const [bets,setBets]=useState([]);

  useEffect(()=>{
    try{ setBets(JSON.parse(localStorage.getItem('mlb-bets-v2')||'[]')); }catch{}
    loadGames();
  },[]);
  useEffect(()=>{ localStorage.setItem('mlb-bets-v2',JSON.stringify(bets)); },[bets]);

  async function loadGames(){
    setLoadingGames(true);
    try{
      const r=await fetch(`/api/mlb?date=${date}`); const j=await r.json();
      if(!j.ok) throw new Error(j.error); setGames(j.games||[]);
    }catch(e){ alert(`載入 MLB 賽程失敗：${e.message}`); }
    finally{ setLoadingGames(false); }
  }

  async function pickImages(files){
    const fs=[...files].slice(0,8);
    const rows=[];
    for(const f of fs){ rows.push({name:f.name,size:f.size,url:URL.createObjectURL(f),data:await fileToDataUrl(f)}); }
    setImages(rows); setVisionStatus(`${rows.length} 張圖片已讀取`);
  }

  async function runVision(){
    if(!images.length) return alert('請先選擇盤口截圖');
    setVisionStatus('AI 正在辨識盤口…');
    try{
      const r=await fetch('/api/vision',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({images:images.map(x=>x.data)})});
      const j=await r.json(); if(!j.ok) throw new Error(j.error);
      const ps=(j.parsed?.games||[]).map((g,idx)=>{
        let best=null,bestScore=-1;
        for(const gm of games){ const sc=teamMatch(g,gm); if(sc>bestScore){best=gm;bestScore=sc;} }
        return {...g,id:`p${Date.now()}-${idx}`,matchedGame:bestScore>0?best:null};
      });
      setParsedGames(ps); setSelectedIndex(0); setVisionStatus(`辨識完成：${ps.length} 場`); setTab('confirm');
    }catch(e){ setVisionStatus(`辨識失敗：${e.message}`); }
  }

  const current=parsedGames[selectedIndex];

  function updateCurrent(fn){ setParsedGames(prev=>prev.map((g,i)=>i===selectedIndex?fn(g):g)); }
  function updateDirection(market,di,key,value){
    updateCurrent(g=>({...g,markets:(g.markets||[]).map(m=>m.market===market?{...m,directions:(m.directions||[]).map((d,i)=>i===di?{...d,[key]:value}:d)}:m)}));
  }
  function setMatchedGame(gamePk){
    const gm=games.find(x=>String(x.gamePk)===String(gamePk)); updateCurrent(g=>({...g,matchedGame:gm||null}));
  }
  function lockCurrent(){
    if(!current?.matchedGame) return alert('請先確認對應的 MLB 賽事');
    const flat=[];
    for(const market of ORDER){
      const m=(current.markets||[]).find(x=>x.market===market);
      for(const d of (m?.directions||[])) if(d?.pick) flat.push({market,pick:d.pick,water:Number(d.water||.95),confidence:Number(d.confidence||0)});
    }
    if(!flat.length) return alert('沒有可鎖定的盤口');
    const row={id:current.id,game:current.matchedGame,markets:flat,lockedAt:new Date().toISOString()};
    setLocked(prev=>[...prev.filter(x=>x.id!==row.id),row]); alert('盤口已鎖定');
  }
  async function analyzeLocked(row){
    setAnalyses(a=>({...a,[row.id]:{loading:true}}));
    try{
      const r=await fetch('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({game:row.game,markets:row.markets})});
      const j=await r.json(); if(!j.ok) throw new Error(j.error); setAnalyses(a=>({...a,[row.id]:j})); setTab('analysis');
    }catch(e){ setAnalyses(a=>({...a,[row.id]:{error:e.message}})); }
  }
  function addBet(game,result){
    setBets(prev=>[{id:crypto.randomUUID(),time:new Date().toISOString(),game:`${game.away} @ ${game.home}`,gamePk:game.gamePk,market:result.market,pick:result.pick,water:result.water,score:result.score,unit:1,result:'未結算',profit:0,closing:null},...prev]);
  }
  function settleBet(id,result){
    setBets(prev=>prev.map(b=>{
      if(b.id!==id) return b; const u=Number(b.unit||1),w=Number(b.water||.95);
      const profit=result==='勝'?u*w:result==='敗'?-u:result==='半勝'?u*w/2:result==='半敗'?-u/2:0;
      return {...b,result,profit};
    }));
  }
  function updateBet(id,key,value){ setBets(prev=>prev.map(b=>b.id===id?{...b,[key]:value}:b)); }

  const stats=useMemo(()=>{
    const done=bets.filter(b=>b.result!=='未結算'); const profit=done.reduce((a,b)=>a+Number(b.profit||0),0); const risk=done.reduce((a,b)=>a+Number(b.unit||0),0);
    return {total:bets.length,done:done.length,w:done.filter(b=>b.result==='勝').length,l:done.filter(b=>b.result==='敗').length,push:done.filter(b=>b.result==='走水').length,profit,roi:risk?profit/risk:0};
  },[bets]);

  return <main className="shell">
    <header className="header"><div><div className="eyebrow">PRIVATE ANALYTICS</div><h1>⚾ MLB Positive EV</h1><p>盤口截圖 → AI 辨識 → 鎖定 → MLB 公開資料 → 8 方向模型 → 下注績效</p></div><div className="badge">v1.0</div></header>
    <nav className="tabs">{[['today','今日賽事'],['upload','📷 上傳'],['confirm','盤口確認'],['analysis','分析結果'],['bets','下注紀錄'],['perf','績效']].map(([k,n])=><button key={k} className={tab===k?'active':''} onClick={()=>setTab(k)}>{n}</button>)}</nav>

    {tab==='today'&&<section>
      <div className="card row between"><div><h2>今日 MLB Dashboard</h2><p className="muted">賽程與 probable pitchers 來自 MLB Stats API。</p></div><div className="row"><input className="date" type="date" value={date} onChange={e=>setDate(e.target.value)}/><button className="primary" onClick={loadGames}>{loadingGames?'載入中…':'重新載入'}</button></div></div>
      <div className="card">{games.length?games.map(g=><div className="gameRow" key={g.gamePk}><div><b>{g.away} @ {g.home}</b><div className="muted">{new Date(g.gameDate).toLocaleString('zh-TW')}｜{g.venue}</div><div className="muted">先發：{g.awayProbable||'未公布'} vs {g.homeProbable||'未公布'}</div></div><span className="pill">{g.status}</span></div>):<p className="muted">沒有賽事或尚未載入。</p>}</div>
    </section>}

    {tab==='upload'&&<section>
      <div className="card"><h2>上傳信用盤截圖</h2><label className="drop">點這裡從 iPhone 相簿選擇截圖<input type="file" accept="image/*" multiple onChange={e=>pickImages(e.target.files)}/><span>最多 8 張；圖片只送到你的 Vercel API 做盤口辨識。</span></label>
      <div className="previews">{images.map((x,i)=><div className="preview" key={i}><img src={x.url} alt="盤口截圖"/><small>{x.name} · {(x.size/1024/1024).toFixed(1)}MB</small></div>)}</div>
      <div className="status">{visionStatus||'尚未選圖'}</div><button className="primary full" onClick={runVision}>開始 AI 辨識盤口</button></div>
    </section>}

    {tab==='confirm'&&<section>
      <div className="card"><h2>盤口確認與鎖定</h2><p className="muted">AI 只負責讀圖。你確認後才鎖定，後續分析不可自行交換讓方／受讓方。</p>
      {!parsedGames.length?<p>尚無辨識結果。</p>:<>
        <div className="chips">{parsedGames.map((g,i)=><button className={i===selectedIndex?'chip activeChip':'chip'} key={g.id} onClick={()=>setSelectedIndex(i)}>{g.away||'?'} @ {g.home||'?'}</button>)}</div>
        <label>配對 MLB 賽事<select value={current?.matchedGame?.gamePk||''} onChange={e=>setMatchedGame(e.target.value)}><option value="">請選擇</option>{games.map(g=><option key={g.gamePk} value={g.gamePk}>{g.away} @ {g.home}</option>)}</select></label>
        {ORDER.map(market=>{const m=(current?.markets||[]).find(x=>x.market===market)||{directions:[]}; const dirs=[...(m.directions||[])]; while(dirs.length<2)dirs.push({pick:'',water:.95,confidence:0}); return <div className="market" key={market}><h3>{market}</h3><div className="two">{dirs.slice(0,2).map((d,di)=><div key={di}><label>方向＋盤口<input value={d.pick||''} onChange={e=>updateDirection(market,di,'pick',e.target.value)} placeholder="例：紅襪讓2+15"/></label><label>水位<input type="number" step=".001" value={d.water??.95} onChange={e=>updateDirection(market,di,'water',e.target.value)}/></label><small>AI 信心：{Math.round(Number(d.confidence||0)*100)}%</small></div>)}</div></div>})}
        <button className="primary full" onClick={lockCurrent}>🔒 確認並鎖定這場盤口</button>
      </>}</div>
      <div className="card"><h2>已鎖定</h2>{locked.length?locked.map(row=><div className="locked" key={row.id}><div><b>{row.game.away} @ {row.game.home}</b><div className="muted">{row.markets.length} 個方向｜{row.game.awayProbable||'未公布'} vs {row.game.homeProbable||'未公布'}</div></div><button className="primary" onClick={()=>analyzeLocked(row)}>{analyses[row.id]?.loading?'分析中…':'開始分析'}</button></div>):<p className="muted">尚未鎖定盤口。</p>}</div>
    </section>}

    {tab==='analysis'&&<section>{locked.map(row=>{const a=analyses[row.id]; if(!a||a.loading||a.error)return null; return <div className="card" key={row.id}><div className="row between"><div><h2>{row.game.away} @ {row.game.home}</h2><p className="muted">先發：{row.game.awayProbable||'未公布'} vs {row.game.homeProbable||'未公布'}｜球場：{row.game.venue}</p></div><span className="pill">盤口已鎖定</span></div>
      <div className="signals"><div><span>客隊 OPS</span><b>{a.analysis.awaySignals.ops.toFixed(3)}</b></div><div><span>主隊 OPS</span><b>{a.analysis.homeSignals.ops.toFixed(3)}</b></div><div><span>客隊 ERA</span><b>{a.analysis.awaySignals.era.toFixed(2)}</b></div><div><span>主隊 ERA</span><b>{a.analysis.homeSignals.era.toFixed(2)}</b></div></div>
      {ORDER.map(market=><div className="market" key={market}><h3>{market}</h3>{a.analysis.results.filter(x=>x.market===market).map((r,i)=><div className={`result ${r.score>=8.5?'best':r.score>=7.2?'candidate':''}`} key={i}><div><div><span className="score">{r.score.toFixed(1)}</span>｜{r.pick}｜{Number(r.water).toFixed(3)} {r.tag&&<span className="tag">{r.tag}</span>}</div><small>模型過盤率 {fmtPct(r.modelProbability)}｜EV {fmtEV(r.ev)}｜穩健 EV {fmtEV(r.robustEV)}｜加權 EV {fmtEV(r.weightedEV)}</small></div><button onClick={()=>addBet(row.game,r)}>已下注</button></div>)}</div>)}
      <div className="note">模型 v1 使用 MLB 公開球季攻守數據、主場因子與即時天氣做價格評估；未公布打線、完整傷停與牛棚逐日負荷目前不會假裝成已取得資料。</div>
    </div>})}{!Object.values(analyses).some(x=>x?.ok)&&<div className="card muted">尚無完成的分析。</div>}</section>}

    {tab==='bets'&&<section><div className="card"><h2>下注紀錄</h2>{bets.length?<div className="tableWrap"><table><thead><tr><th>時間</th><th>比賽</th><th>投注</th><th>評分</th><th>Unit</th><th>結果</th><th>盈虧</th></tr></thead><tbody>{bets.map(b=><tr key={b.id}><td>{new Date(b.time).toLocaleString('zh-TW')}</td><td>{b.game}</td><td>{b.market}<br/>{b.pick}｜{Number(b.water).toFixed(3)}</td><td>{Number(b.score).toFixed(1)}</td><td><input className="tiny" type="number" step=".5" value={b.unit} onChange={e=>updateBet(b.id,'unit',Number(e.target.value))}/></td><td><select value={b.result} onChange={e=>settleBet(b.id,e.target.value)}><option>未結算</option><option>勝</option><option>敗</option><option>走水</option><option>半勝</option><option>半敗</option></select></td><td>{Number(b.profit||0).toFixed(2)} U</td></tr>)}</tbody></table></div>:<p className="muted">尚無下注紀錄。</p>}</div></section>}

    {tab==='perf'&&<section><div className="card"><h2>績效 Dashboard</h2><div className="signals"><div><span>總下注</span><b>{stats.total}</b></div><div><span>勝 / 敗 / 走</span><b>{stats.w} / {stats.l} / {stats.push}</b></div><div><span>ROI</span><b>{(stats.roi*100).toFixed(2)}%</b></div><div><span>總盈虧</span><b>{stats.profit.toFixed(2)} U</b></div></div>
      <h3>評分區間</h3><div className="barList"><div>8.5+：{bets.filter(b=>b.score>=8.5).length}</div><div>7.2–8.4：{bets.filter(b=>b.score>=7.2&&b.score<8.5).length}</div><div>&lt;7.2：{bets.filter(b=>b.score<7.2).length}</div></div>
      <p className="muted">CLV 欄位已保留資料結構，但需要你輸入或後續串接收盤盤口來源後才能正式計算。</p></div></section>}
  </main>;
}
