# MLB Positive EV 私人版

完整可部署的 Next.js 第一版。

## 已完成

- iPhone 多張盤口截圖選取、縮圖預覽
- Vercel AI Gateway Vision 盤口辨識
- 台灣信用盤字串原樣保留
- AI 辨識後人工確認與「盤口鎖定層」
- MLB Stats API 今日賽程與 probable pitchers
- Open-Meteo 球場即時天氣
- 四市場八方向固定輸出結構
- 模型過盤率、EV、穩健 EV、加權 EV、最終評分
- 7.2+ 下注候選、8.5+ 最強主推
- 一鍵加入下注紀錄
- 勝 / 敗 / 走水 / 半勝 / 半敗結算
- ROI、總盈虧、評分區間
- 下注資料保存在瀏覽器 localStorage，私人第一版不需資料庫

## Vercel 環境變數

必填：

`AI_GATEWAY_API_KEY=你的 vck_...`

可選：

`AI_MODEL=google/gemini-2.5-flash`

若 Vercel AI Gateway 當下不支援預設模型，請在環境變數把 `AI_MODEL` 改成帳號可用且支援圖片的模型 ID。

## 部署

1. 將整個資料夾上傳到 GitHub repository 根目錄。
2. Vercel Project 連接該 repository。
3. Framework Preset 選 Next.js（通常自動偵測）。
4. 加入 `AI_GATEWAY_API_KEY`。
5. Deploy。

## 分析模型說明

這是可運作的 v1 模型，不會假裝取得不存在的資料。它目前使用 MLB 公開球季攻守數據、主場因子與球場天氣估計價格優勢。probable pitchers 會顯示在介面，但 v1 尚未以逐投手進階指標、正式打線、完整傷停與每日牛棚使用量做完整量化。

若要升級成你的正式長期研究模型，下一版應加入：

- 先發投手 xFIP / SIERA / K-BB% / platoon splits
- bullpen rolling 3/7/14 day workload + leverage availability
- projected/official lineup wRC+ / handedness / catcher
- injuries / rest / travel
- park factors / roof / umpire distribution
- closing line snapshot & CLV
- 按盤口結算分支的台灣信用盤精準 EV 引擎

> 重要：網站是分析工具；模型評分應以長期回測校準，不應把單場結果當成模型有效性的證明。
